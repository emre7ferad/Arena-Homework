﻿namespace ArenaGame
{
    public class Warrior : Hero
    {
        private const int BerserkChance = 15;

        public Warrior() : this("Kiro")
        {
        }

        public Warrior(string name) : base(name)
        {
            Strength = 120;
        }

        public override int Attack()
        {
            int attack = base.Attack();
            if (ThrowDice(BerserkChance))
            {
                attack = attack * 2;
            }
            return attack;
        }

        public override void TakeDamage(int incomingDamage)
        {
            base.TakeDamage(incomingDamage);
        }
    }
}
