﻿namespace ArenaGame
{
    public class Mage : Hero
    {
        private const int MagicDamageMultiplier = 2;
        private const int HealingChance = 20;

        public Mage() : this("Vankata")
        {
        }

        public Mage(string name) : base(name)
        {
            Strength = 80; 
        }

        public override int Attack()
        {
            int attack = base.Attack();
            if (ThrowDice(HealingChance))
            {
                Heal(StartingHealth * 20 / 100);
            }
            return attack * MagicDamageMultiplier;
        }

        public override void TakeDamage(int incomingDamage)
        {
            base.TakeDamage(incomingDamage);
        }
    }
}
