﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public class Bow : IWeapon
    {
        public int Damage { get; private set; } = 10;
        public string SpecialAbility { get; private set; } = "Pierce";
    }
}